import { LightningElement, wire } from 'lwc';
import getStaleRecordsCount from '@salesforce/apex/StaleRecordsController.getStaleRecordsCount';

export default class StaleRecordsCount extends LightningElement {
    staleLeads = 0;
    staleOpportunities = 0;

    @wire(getStaleRecordsCount)
    wiredStaleRecordsCount({ error, data }) {
        if (data) {
            this.staleLeads = data.staleLeads;
            this.staleOpportunities = data.staleOpportunities;
        } else if (error) {
            console.error('Error retrieving stale records counts:', error);
        }
    }
}
